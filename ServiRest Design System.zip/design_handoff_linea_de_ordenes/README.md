# Handoff: POS — Línea de Órdenes (ServiRest)

> Paquete de implementación para llevar el rediseño de la pantalla **POS / Línea de
> Órdenes** (y el sistema de marca **Sobremesa Lúcida**) al repositorio
> [`JulioRonin/restaurant-POS`](https://github.com/JulioRonin/restaurant-POS) —
> React + TypeScript + Tailwind + Vite + Supabase.

---

## Overview

Esta es la pantalla principal que ve un **mesero/cajero** en el POS de ServiRest. Reemplaza
el "Comandero" anterior por un layout tipo **"Línea de Órdenes"**: una columna principal con
banner promocional + tarjetas de órdenes en preparación + menú con tabs y grid de platillos,
y una **barra de orden actual** (recibo) fija a la derecha. El objetivo es que el mesero vea
de un vistazo qué se está cocinando y arme/cobre la orden en curso sin cambiar de pantalla.

El rediseño adopta la **estructura** de una referencia de UI que aportó el cliente, pero
mantiene **el 100% del branding ServiRest** (paleta Sobremesa Lúcida, tipografías
Fraunces/Inter/JetBrains Mono, logo El Plato Asimétrico, iconos Lucide). Solo cambió el
**layout**, no el lenguaje visual.

## About the Design Files

Los archivos en `reference/` son **referencias de diseño hechas en HTML/React-vía-Babel** —
prototipos que muestran el look y el comportamiento buscados, **no código de producción para
copiar tal cual**. La tarea es **recrear estos diseños dentro del entorno existente del
repo** (`restaurant-POS`: componentes React + TypeScript, utilidades Tailwind, `lucide-react`,
React Router, Framer Motion) usando sus patrones ya establecidos.

Concretamente: el prototipo usa CSS plano con clases `.ol-*`/`.fcard`/`.rail-*` y carga React
por CDN con Babel en el navegador. En el repo real eso se traduce a **componentes `.tsx` con
clases Tailwind** (o CSS Modules, según el patrón del proyecto) y `lucide-react` importado como
módulo. No hace falta arrastrar `kit.css`; está incluido como **fuente de verdad de medidas,
colores y estados** para que reproduzcas cada valor con fidelidad.

## Fidelity

**Alta fidelidad (hifi).** Colores, tipografía, espaciados, radios, sombras y estados son los
definitivos. Reprodúcelos pixel-perfect usando los tokens de `tokens/colors_and_type.css`.
Donde el repo ya tenga un token equivalente (ver `tailwind.config.js` → `servirest.*`), usa el
del repo; los hex de este doc deben coincidir con él.

---

## Screens / Views

### 1. POS — Línea de Órdenes  (la pantalla de este handoff)

Ruta sugerida: la que hoy monta `screens/POS.tsx`. Archivo de referencia: `reference/POS.jsx`.

**Layout (raíz `.ol`):** dos columnas, `display:flex`, alto `100%`, fondo `#FAF8F4` (hueso).
- **Columna principal `.ol-main`** — `flex:1`, scroll vertical, `padding: 34px 32px 40px`.
- **Rail derecho `.order-rail`** — ancho fijo **348px**, `flex-shrink:0`, fondo blanco
  `#FFFFFF`, borde izquierdo `1px solid rgba(42,40,38,.12)`, columna flex.

La columna principal apila, de arriba a abajo:

**a) Título de página** — "Línea de Órdenes". Fraunces 500, 32px, `letter-spacing:-0.02em`,
color midnight `#1A1E2E`. Margen inferior 22px.

**b) Banner promocional `.promo`** (descartable):
- Contenedor: `display:flex; align-items:center; gap:22px; padding:18px 22px`,
  `border:1px solid rgba(196,99,63,.45)`, `border-radius:24px`, fondo blanco, sombra de card.
- Chip izquierdo `.promo-chip`: 56×56, `border-radius:16px`, fondo midnight `#1A1E2E`, icono
  Lucide `cpu` en mostaza `#C9A24A`, 26px.
- Texto: `h3` Inter 800 16px midnight ("No te pierdas la nueva versión de ServiRest"); `p`
  Inter 500 12px, color `rgba(42,40,38,.60)`.
- CTA `.promo-cta`: pill terracota `#C4633F`, texto hueso, Inter 900 italic uppercase 10px,
  `letter-spacing:.14em`, `padding:13px 22px`, `border-radius:14px`, sombra
  `0 0 20px rgba(196,99,63,.40)`, icono `rocket` 14px. Hover: `scale(1.04)`.
- Botón cerrar `.promo-x`: círculo 26px arriba-derecha (absolute, top/right 12px), icono `x`.
  Al cerrar, oculta el banner (estado `promo=false`).

**c) Tarjetas de progreso de órdenes `.ol-cards`** — el feature central:
- Grid: `repeat(auto-fill, minmax(280px, 1fr))`, `gap:16px`.
- Cada `.ol-card`: fondo blanco, `border:1px solid rgba(42,40,38,.12)`, `border-radius:24px`,
  `padding:20px`, sombra de card. Hover: `translateY(-3px)` + sombra lift + borde
  `rgba(196,99,63,.3)`.
  - **Fila superior `.oc-top`**: ID de orden en JetBrains Mono 600 12px terracota
    (`#231128001`); a la derecha pill de mesa `.oc-table` (Inter 800 9px uppercase,
    `border:1px solid rgba(42,40,38,.20)`, `border-radius:999px`, `padding:5px 11px`).
  - **Nombre cliente `.oc-name`**: Inter 800 18px midnight, margen inferior 18px.
  - **Pie `.oc-foot`** (`border-top:1px solid line`, `padding-top:16px`, `gap:12px`):
    - **Anillo de progreso `.ring`** 44×44: SVG con dos `<circle>` r=18, `stroke-width:4`.
      Track `rgba(196,99,63,.15)`; progreso terracota con `stroke-linecap:round`,
      `stroke-dasharray = 2πr`, `stroke-dashoffset = circ*(1 - pct/100)`, SVG rotado −90°.
      Centro: % en Inter 900 italic 9px terracota.
    - "En preparación" (Inter 800 12px midnight, `flex:1`).
    - Conteo `.oc-items`: "N platillos" + círculo 26px `rgba(196,99,63,.10)` con flecha
      `arrow-right` terracota 13px.
  - Datos demo: 4 órdenes (85/60/40/20%). Ver `reference/data.js` → `SR.ORDERS`. En
    producción esto viene de las órdenes activas (Supabase).

**d) Sección "Menú" `.ol-sec`** — fila con título "Menú" (Fraunces 500 32px) a la izquierda y
controles a la derecha `.menu-search`:
- Input de búsqueda `.sb`: ancho 320px, pill (`border-radius:999px`), `border:1px solid
  rgba(42,40,38,.20)`, `padding:13px 16px 13px 44px`, icono `search` 16px absoluto a 16px.
  Focus: borde terracota.
- Botón filtro `.menu-filter`: círculo 48px, borde line, icono `sliders-horizontal` 18px.
  Hover: borde+icono terracota.

**e) Tabs de categorías `.tabs`** — fila scrollable, `gap:26px`, `border-bottom:1px solid
line`. Cada `.tab`: Inter 700 14px, color `rgba(42,40,38,.60)`. Activo: terracota, peso 800,
subrayado `::after` de 3px terracota pegado al borde inferior. Tabs demo: Plato Fuerte,
Entradas, Tacos, Favoritos, Bebidas, Postres, Ensaladas, Sopas (ver `SR.TABS`).

**f) Grid de platillos `.fgrid`** — `repeat(auto-fill, minmax(190px, 1fr))`, `gap:22px 20px`.
Cada `.fcard` (botón, fondo transparente, texto izquierda; hover `translateY(-4px)`):
- `.fimg`: alto 150px, `border-radius:16px`, overflow hidden, sombra card. `img`
  `object-fit:cover`; hover `scale(1.07)` en 0.5s.
- Botón add `.fadd`: círculo 34px terracota abajo-derecha, icono `plus` 17px, aparece en hover
  (`opacity 0→1` + `translateY(6px)→0`), sombra glow.
- Si no disponible: badge `.fout` "Agotado" arriba-izquierda (Inter 900 8px uppercase, fondo
  `rgba(225,85,75,.92)`, hueso). La card baja a `opacity:.6`.
- `.frow`: nombre `.fn` (Inter 800 15px midnight) + precio `.fp` (Inter 800 14px terracota,
  formato `$NNN.NN`).
- `.fsub`: subtítulo Inter 500 11px `rgba(42,40,38,.60)` — categoría (+ "· variantes" si aplica).
- Tap: si el platillo tiene `variants`, abre **modal de variantes**; si no, agrega a la orden.

**Rail derecho — "Orden Actual" `.order-rail`:**
- **Header `.rail-head`** (`padding:28px 26px 18px`): título "Orden Actual" (Fraunces 500 26px
  midnight) + meta `.rh-meta`: `#231128005` (terracota) · "Mesa 12 · Rachmad".
- **Body `.rail-body`** (scroll, `padding:6px 26px`): lista de `.rail-item`
  (`padding:13px 0; border-bottom:1px solid line; gap:13px`):
  - `.ri-q`: cuadro 30px `border-radius:9px` `rgba(196,99,63,.10)`, cantidad en Inter 900
    italic 12px terracota.
  - `.ri-n`: nombre `.ri-name` (Inter 700 13px midnight) + sub `.ri-sub` (Inter 600 10px
    `rgba(42,40,38,.40)`, variantes o "Sin indicaciones").
  - `.ri-p`: precio de línea, Inter 800 13px midnight.
  - Vacío: `.rail-empty` centrado, Inter 700 11px uppercase `letter-spacing:.16em`.
- **Footer `.rail-foot`** (`padding:22px 26px; border-top:1px solid line; background:#F0F0E8`):
  - Líneas Subtotal e "IVA (16%)" (`.rail-line`: label `rgba(42,40,38,.60)` 12px / valor
    JetBrains Mono 700).
  - **Total `.rail-total`**: separador punteado arriba; label "Total" (Inter 900 10px
    uppercase `.2em`) + valor (Inter 900 italic 28px midnight, `letter-spacing:-0.03em`).
  - Botón **"Procesar Pago"** `.btn-primary` ancho completo (terracota, Inter 900 italic
    uppercase, glow, icono `arrow-right`). `disabled` si la orden está vacía (`opacity:.25`,
    sin sombra). Cálculo: `subtotal = Σ líneas`, `tax = subtotal*0.16`, `total = subtotal+tax`.

### 2. Modales (compartidos)

- **Modal de variantes** — scrim `rgba(10,12,20,.92)` + `backdrop-filter:blur(14px)`. Card
  blanca `border-radius:32px`, `padding:40px`, `max-width:480px`. Cada opción es un botón
  toggle: borde terracota 2px + fondo `rgba(196,99,63,.08)` cuando está activa, con radio-check
  (círculo 22px que se llena de terracota con icono `check`). Precio: "+$NN" o "Incluido".
  CTA "Agregar a la orden".
- **Éxito** — al procesar pago: scrim + card centrada `.success`, anillo 104px terracota con
  icono `check` 52px midnight (animación `pop`), "¡Pago procesado!" (Inter 900 italic 30px) +
  "Orden enviada a cocina". Se cierra solo a los ~2.2s y vacía la orden.

### 3. Otras vistas incluidas en el prototipo (contexto, ya existen en el repo)

- **Dashboard** (`reference/Dashboard.jsx`) — KPIs, gráfica de ventas por día, distribución de
  gastos, best-sellers. Recreación de marca sobre `screens/Dashboard.tsx`.
- **Splash / Lock / Sidebar** (`reference/Shell.jsx`, `App.jsx`) — splash de marca, selección
  de perfil (lock) y sidebar oscuro expandible (96→256px al hover). Equivalen a
  `components/Sidebar.tsx`, `components/Logo.tsx` y el flujo de auth del repo.

---

## Interactions & Behavior

| Acción | Comportamiento |
|---|---|
| Tap en platillo sin variantes | Agrega 1 a "Orden Actual" (o +1 si ya existe la misma línea). |
| Tap en platillo con variantes | Abre modal; selección múltiple; "Agregar" crea la línea con sus variantes (clave de dedup = variantes ordenadas). |
| Cambiar tab | Filtra el grid por categoría; si una categoría no tiene platillos, cae al menú completo (solo demo). |
| Buscar | Filtra por nombre (case-insensitive) dentro de la categoría activa. |
| Cerrar banner | Oculta el promo (no persiste; en prod, recordar dismissal). |
| Procesar Pago | Disabled si la orden está vacía. Muestra éxito, espera ~2.2s, limpia la orden. |
| Hover cards/platillos | Lift + sombra; en platillo aparece el botón add y zoom de imagen. |

**Animaciones:** transiciones de hover 0.18–0.5s con ease-out
(`cubic-bezier(0.16,1,0.3,1)`); panel/sidebar usan `cubic-bezier(0.23,1,0.32,1)` ("solaris").
El anillo de progreso anima `stroke-dashoffset` (0.6s). En el repo, Framer Motion es el
equivalente. **Importante:** no condiciones la *visibilidad* del contenido a una animación de
entrada (en el prototipo se quitaron los fade-up de las tarjetas justo por eso) — anima
transform/escala, nunca opacidad de 0 sobre contenido que debe verse en print/PDF.

## State Management

Estado local de la pantalla (en el repo, `useState` o el store que ya use POS):
- `tab: string` — categoría activa.
- `q: string` — texto de búsqueda.
- `order: OrderLine[]` — líneas de la orden actual (`{ id, name, price, qty, variants[] }`).
- `variantItem / picked` — platillo abierto en modal y sus variantes elegidas.
- `success: boolean` — overlay de pago.
- `promo: boolean` — visibilidad del banner.

**Data fetching (producción):** `SR.ORDERS` (tarjetas de progreso) y el menú vienen de
Supabase. El % de cada orden puede derivarse del estado de sus ítems en cocina (KDS). La
"Orden Actual" es la orden abierta de la mesa seleccionada.

## Design Tokens

Fuente única: **`tokens/colors_and_type.css`** (CSS variables) — alineado con
`tailwind.config.js → theme.extend.colors.servirest` del repo.

**Color (paleta Sobremesa Lúcida — 5 hex):**
| Token | Hex | Uso |
|---|---|---|
| `--midnight` | `#1A1E2E` | Primary · sidebar, headings, chip oscuro |
| `--terracota` | `#C4633F` | Secondary · CTA, activos, precios, anillos |
| `--mostaza` | `#C9A24A` | Accent · señales, números KPI, icono del chip |
| `--hueso` | `#FAF8F4` | Surface · canvas de la app |
| `--carbon` | `#2A2826` | Texto cuerpo sobre crema |
| Apoyos | `#FFFFFF` surface · `#F0F0E8` sunken · `#A14C2D` terracota-dark · `#22A06B` success · `#E1554B` danger | |
| Líneas | `rgba(42,40,38,.12)` hairline · `rgba(42,40,38,.20)` strong | |

Regla: **terracota = emoción** (CTA/activos). **mostaza = información** (badges/números).
Cero negro puro, cero blanco puro.

**Tipografía** (Google Fonts; ya importadas en el repo):
- **Fraunces** (serif variable) — display/títulos, casi siempre italic, `opsz 144`.
- **Inter** — funcional; firma "brutal": `900 italic UPPERCASE` con tracking negativo en
  headers/KPIs/CTAs.
- **JetBrains Mono** — precios, IDs, timestamps.

**Radios:** 8 / 12 / 16 / 24 (card) / 32 (modal·"solaris") / 999 (pill).
**Sombras:** card `0 2px 20px rgba(42,40,38,.08)` · lift `0 4px 24px rgba(42,40,38,.10)` ·
modal `0 30px 80px rgba(26,30,46,.35)` · glow terracota `0 0 20px rgba(196,99,63,.40)`.
**Espaciado:** múltiplos de 4; gaps típicos 12/16/22/26px; paddings de página 32–34px.

## Assets

En `assets/`:
- `logo-plato-light.svg` / `logo-plato-midnight.svg` — **El Plato Asimétrico** (no redibujar).
- `favicon.svg` — marca con trazo grueso.
- `food/aguachile.png`, `ceviche.png`, `tostada.png` — fotografía real (importada del repo,
  `public/images/`). En producción, usar las imágenes reales de cada platillo desde Supabase.
- **Iconos:** [Lucide](https://lucide.dev) (`lucide-react` ya está en el repo). Glifos usados:
  `cpu, rocket, x, search, sliders-horizontal, plus, arrow-right, check`.

## Files

**Referencia (lo que debes recrear):**
- `reference/POS.jsx` — la pantalla Línea de Órdenes (foco de este handoff).
- `reference/kit.css` — medidas/colores/estados exactos (clases `.ol-*`, `.fcard`, `.rail-*`,
  `.promo*`, `.ring`, modales). **Fuente de verdad de valores.**
- `reference/data.js` — shape de datos demo (`SR.ORDERS`, `SR.MENU`, `SR.TABS`, `SR.SEED_ORDER`).
- `reference/Shell.jsx`, `Dashboard.jsx`, `App.jsx` — contexto (sidebar, dashboard, flujo).
- `reference/index.html` — cómo se monta todo (solo para correr el prototipo localmente).

**Tokens y marca:**
- `tokens/colors_and_type.css` — todos los tokens + clases primitivas `.sr-*`.
- `brand/BRAND.md` — biblia de marca completa (voz, copy, fundamentos visuales, iconografía).

**Cómo correr el prototipo:** abre `reference/index.html` en un servidor estático
(p. ej. `npx serve design_handoff_linea_de_ordenes/reference`). Carga React+Babel por CDN.

---

## Mapa de implementación en `restaurant-POS` (sugerido)

1. **Tokens** — confirma que `tailwind.config.js → servirest.*` cubre los 5 hex + apoyos; si
   falta alguno (sunken `#F0F0E8`, success/danger), agrégalo. No introduzcas la paleta vieja
   KŌSO (olive/salmon) que aún vive hardcodeada en `screens/POS.tsx`.
2. **Reemplaza `screens/POS.tsx`** por el layout Línea de Órdenes. Extrae subcomponentes:
   `<OrderProgressCard>`, `<ProgressRing>`, `<MenuTabs>`, `<DishCard>`, `<CurrentOrderRail>`,
   `<VariantModal>`, `<PaymentSuccess>`, `<PromoBanner>`.
3. **Iconos** con `lucide-react` (import nombrado), no CDN.
4. **Animaciones** con Framer Motion (ya en el repo); respeta la regla de no ocultar contenido.
5. **Datos** desde Supabase: órdenes activas → tarjetas; orden abierta de la mesa → rail.
6. Mantén Fraunces/Inter/JetBrains y el copy en español (ver `brand/BRAND.md` para tono).
