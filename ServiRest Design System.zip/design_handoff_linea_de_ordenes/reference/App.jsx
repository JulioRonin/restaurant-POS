/* ServiRest POS kit — App orchestrator */

const Placeholder = ({ id }) => {
  const { NAV } = window.SR;
  const item = NAV.find(n => n.id === id) || { label: id, icon: 'circle' };
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, background: 'var(--hueso)', padding: 40, textAlign: 'center' }}>
      <div style={{ width: 88, height: 88, borderRadius: 28, background: 'rgba(196,99,63,0.08)', border: '1px solid rgba(196,99,63,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#C4633F' }}>
        <i data-lucide={item.icon} style={{ width: 40, height: 40 }}></i>
      </div>
      <div style={{ fontFamily: 'var(--font-serif)', fontStyle: 'italic', fontWeight: 500, fontSize: 32, color: '#1A1E2E', letterSpacing: '-0.02em' }}>{item.label}</div>
      <div style={{ maxWidth: 380, fontWeight: 800, fontSize: 11, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'rgba(42,40,38,0.4)', lineHeight: 1.7 }}>
        Módulo del producto real · no recreado en este UI kit. Explora POS y Dashboard.
      </div>
    </div>
  );
};

const App = () => {
  const [stage, setStage] = React.useState('splash'); // splash | lock | app
  const [employee, setEmployee] = React.useState(null);
  const [route, setRoute] = React.useState('pos');

  React.useEffect(() => {
    const t = setTimeout(() => setStage('lock'), 1700);
    return () => clearTimeout(t);
  }, []);
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  if (stage === 'splash') return <Splash />;
  if (stage === 'lock') return <Lock onPick={(e) => { setEmployee(e); setRoute(e.home); setStage('app'); }} />;

  return (
    <div className="app">
      <Sidebar active={route} onNav={setRoute} employee={employee}
        onLock={() => { setStage('lock'); setEmployee(null); }} />
      <div className="main">
        {route === 'pos' ? <POS />
          : route === 'dashboard' ? <Dashboard />
          : <Placeholder id={route} />}
      </div>
    </div>
  );
};

window.App = App;
