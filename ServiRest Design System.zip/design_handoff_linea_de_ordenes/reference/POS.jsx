/* ServiRest POS kit — "Order Line" screen (reference layout, ServiRest branding) */

const Ring = ({ pct }) => {
  const r = 18, c = 2 * Math.PI * r;
  return (
    <div className="ring">
      <svg width="44" height="44" viewBox="0 0 44 44">
        <circle cx="22" cy="22" r={r} fill="none" stroke="rgba(196,99,63,0.15)" strokeWidth="4" />
        <circle cx="22" cy="22" r={r} fill="none" stroke="#C4633F" strokeWidth="4" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct / 100)} />
      </svg>
      <span className="rpct">{pct}%</span>
    </div>
  );
};

const POS = () => {
  const { MENU, TABS, ORDERS, SEED_ORDER } = window.SR;
  const [tab, setTab] = React.useState('Plato Fuerte');
  const [q, setQ] = React.useState('');
  const [order, setOrder] = React.useState(SEED_ORDER.map(i => ({ ...i, line: Math.random() })));
  const [variantItem, setVariantItem] = React.useState(null);
  const [picked, setPicked] = React.useState([]);
  const [success, setSuccess] = React.useState(false);
  const [promo, setPromo] = React.useState(true);

  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  const byTab = MENU.filter(m => m.category === tab);
  const base = byTab.length ? byTab : MENU;
  const items = base.filter(m => m.name.toLowerCase().includes(q.toLowerCase()));

  const add = (item, variants = []) => {
    setOrder(prev => {
      const key = variants.map(v => v.name).sort().join('|');
      const ex = prev.find(i => i.id === item.id && (i.variants || []).map(v => v.name).sort().join('|') === key);
      if (ex) return prev.map(i => i === ex ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { id: item.id, name: item.name, price: item.price, qty: 1, variants, line: Math.random() }];
    });
    setVariantItem(null); setPicked([]);
  };
  const lineTotal = (i) => (i.price + (i.variants || []).reduce((s, v) => s + (v.price || 0), 0)) * i.qty;
  const subtotal = order.reduce((s, i) => s + lineTotal(i), 0);
  const tax = subtotal * 0.16;
  const total = subtotal + tax;

  const pay = () => { if (!order.length) return; setSuccess(true); setTimeout(() => { setSuccess(false); setOrder([]); }, 2200); };

  return (
    <div className="ol">
      <div className="ol-main no-sb">
        <h1 className="ol-title">Línea de Órdenes</h1>

        {promo && (
          <div className="promo" style={{ marginBottom: 22 }}>
            <div className="promo-chip"><i data-lucide="cpu" style={{ width: 26, height: 26 }}></i></div>
            <div className="promo-text">
              <h3>No te pierdas la nueva versión de ServiRest</h3>
              <p>Actualiza pronto para descubrir las nuevas funciones que agregamos para tu restaurante.</p>
            </div>
            <button className="promo-cta"><i data-lucide="rocket" style={{ width: 14, height: 14 }}></i>Actualizar</button>
            <button className="promo-x" onClick={() => setPromo(false)}><i data-lucide="x" style={{ width: 14, height: 14 }}></i></button>
          </div>
        )}

        <div className="ol-cards">
          {ORDERS.map((o, i) => (
            <div key={o.id} className="ol-card">
              <div className="oc-top">
                <span className="oc-id">{o.id}</span>
                <span className="oc-table">{o.table}</span>
              </div>
              <div className="oc-name">{o.name}</div>
              <div className="oc-foot">
                <Ring pct={o.pct} />
                <span className="oc-status">En preparación</span>
                <span className="oc-items">{o.items} platillos <span className="arr"><i data-lucide="arrow-right" style={{ width: 13, height: 13 }}></i></span></span>
              </div>
            </div>
          ))}
        </div>

        <div className="ol-sec">
          <h2 className="ol-title">Menú</h2>
          <div className="menu-search">
            <div className="sb">
              <i data-lucide="search" style={{ width: 16, height: 16 }}></i>
              <input placeholder="Buscar platillo..." value={q} onChange={e => setQ(e.target.value)} />
            </div>
            <button className="menu-filter"><i data-lucide="sliders-horizontal" style={{ width: 18, height: 18 }}></i></button>
          </div>
        </div>

        <div className="tabs no-sb">
          {TABS.map(t => (
            <button key={t} className={`tab ${tab === t ? 'on' : ''}`} onClick={() => setTab(t)}>{t}</button>
          ))}
        </div>

        <div className="fgrid">
          {items.map(item => (
            <button key={item.id} className="fcard" onClick={() => item.variants ? setVariantItem(item) : add(item)} style={{ opacity: item.available ? 1 : 0.6 }}>
              <div className="fimg">
                <img src={item.img} alt={item.name} />
                {!item.available && <span className="fout">Agotado</span>}
                <span className="fadd"><i data-lucide="plus" style={{ width: 17, height: 17 }}></i></span>
              </div>
              <div className="frow">
                <span className="fn">{item.name}</span>
                <span className="fp">${item.price.toFixed(2)}</span>
              </div>
              <div className="fsub">{item.category}{item.variants ? ' · variantes' : ''}</div>
            </button>
          ))}
        </div>
      </div>

      {/* current order rail */}
      <div className="order-rail">
        <div className="rail-head">
          <h2>Orden Actual</h2>
          <div className="rh-meta"><span className="tt">#231128005</span><span>·</span><span>Mesa 12 · Rachmad</span></div>
        </div>
        <div className="rail-body no-sb">
          {order.length === 0 ? (
            <div className="rail-empty">Agrega platillos del menú para iniciar la orden</div>
          ) : order.map(i => (
            <div key={i.line} className="rail-item">
              <span className="ri-q">{i.qty}</span>
              <div className="ri-n">
                <div className="ri-name">{i.name}</div>
                <div className="ri-sub">{(i.variants || []).length ? i.variants.map(v => v.name).join(', ') : 'Sin indicaciones'}</div>
              </div>
              <span className="ri-p">${lineTotal(i).toFixed(0)}</span>
            </div>
          ))}
        </div>
        <div className="rail-foot">
          <div className="rail-line"><span className="ll">Subtotal</span><span className="lv">${subtotal.toFixed(2)}</span></div>
          <div className="rail-line"><span className="ll">IVA (16%)</span><span className="lv">${tax.toFixed(2)}</span></div>
          <div className="rail-total"><span className="tl">Total</span><span className="tv">${total.toFixed(2)}</span></div>
          <button className="btn-primary" style={{ width: '100%' }} disabled={!order.length} onClick={pay}>
            Procesar Pago <i data-lucide="arrow-right" style={{ width: 18, height: 18 }}></i>
          </button>
        </div>
      </div>

      {/* variant modal */}
      {variantItem && (
        <div className="scrim" onClick={() => { setVariantItem(null); setPicked([]); }}>
          <div className="modal" style={{ maxWidth: 480 }} onClick={e => e.stopPropagation()}>
            <div className="modal-head">
              <div><h2>{variantItem.name}</h2><p>Elige las variantes</p></div>
              <button className="x" onClick={() => { setVariantItem(null); setPicked([]); }}><i data-lucide="x" style={{ width: 22, height: 22 }}></i></button>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {variantItem.variants.map((v, i) => {
                const on = picked.some(p => p.name === v.name);
                return (
                  <button key={i} onClick={() => setPicked(p => on ? p.filter(x => x.name !== v.name) : [...p, v])}
                    style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 18, borderRadius: 20, border: `2px solid ${on ? '#C4633F' : 'var(--line)'}`, background: on ? 'rgba(196,99,63,0.08)' : '#fff' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                      <span style={{ width: 22, height: 22, borderRadius: '50%', border: `2px solid ${on ? '#C4633F' : 'rgba(42,40,38,0.2)'}`, background: on ? '#C4633F' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        {on && <i data-lucide="check" style={{ width: 12, height: 12, color: '#fff' }}></i>}
                      </span>
                      <span style={{ fontWeight: 800, fontSize: 15, color: on ? '#C4633F' : '#1A1E2E' }}>{v.name}</span>
                    </span>
                    <span style={{ fontWeight: 800, color: on ? 'rgba(196,99,63,0.7)' : 'rgba(42,40,38,0.4)' }}>{v.price ? `+$${v.price}` : 'Incluido'}</span>
                  </button>
                );
              })}
            </div>
            <button className="btn-primary" style={{ width: '100%', marginTop: 28 }} onClick={() => add(variantItem, picked)}>
              Agregar a la orden <i data-lucide="plus" style={{ width: 18, height: 18 }}></i>
            </button>
          </div>
        </div>
      )}

      {/* success */}
      {success && (
        <div className="scrim">
          <div className="modal success">
            <div className="ring" style={{ width: 'auto', height: 'auto' }}>
              <div style={{ width: 104, height: 104, borderRadius: '50%', background: '#C4633F', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'var(--glow-terracota)' }}>
                <i data-lucide="check" style={{ width: 52, height: 52, color: '#1A1E2E' }}></i>
              </div>
            </div>
            <h2 style={{ marginTop: 28 }}>¡Pago procesado!</h2>
            <p>Orden enviada a cocina</p>
          </div>
        </div>
      )}
    </div>
  );
};

window.POS = POS;
