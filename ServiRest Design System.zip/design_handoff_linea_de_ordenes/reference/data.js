/* ServiRest POS kit — mock data (plain global JS) */
window.SR = window.SR || {};

const AGU = '../../assets/food/aguachile.png';
const CEV = '../../assets/food/ceviche.png';
const TOS = '../../assets/food/tostada.png';

window.SR.MENU = [
  { id: 'm1', name: 'Aguachile Verde',     category: 'Entradas',    price: 220, img: AGU, available: true },
  { id: 'm2', name: 'Ceviche de Pescado',  category: 'Entradas',    price: 185, img: CEV, available: true },
  { id: 'm3', name: 'Tostada de Atún',      category: 'Tacos',       price: 95,  img: TOS, available: true,
    variants: [ { name: 'Extra atún', price: 35 }, { name: 'Sin cebolla', price: 0 }, { name: 'Aguacate', price: 25 } ] },
  { id: 'm4', name: 'Aguachile Negro',     category: 'Plato Fuerte', price: 245, img: AGU, available: true },
  { id: 'm5', name: 'Ceviche Mixto',       category: 'Plato Fuerte', price: 215, img: CEV, available: true },
  { id: 'm6', name: 'Tostada de Camarón',  category: 'Tacos',       price: 110, img: TOS, available: false },
  { id: 'm7', name: 'Aguachile de Callo',  category: 'Entradas',    price: 280, img: AGU, available: true },
  { id: 'm8', name: 'Ceviche Verde',       category: 'Plato Fuerte', price: 195, img: CEV, available: true },
  { id: 'm9', name: 'Tostada Mixta',        category: 'Tacos',       price: 125, img: TOS, available: true,
    variants: [ { name: 'Doble proteína', price: 45 }, { name: 'Picante', price: 0 } ] },
  { id: 'm10', name: 'Aguachile Clásico',  category: 'Entradas',    price: 210, img: AGU, available: true },
  { id: 'm11', name: 'Ceviche del Día',    category: 'Plato Fuerte', price: 230, img: CEV, available: true },
  { id: 'm12', name: 'Tostada Vegana',     category: 'Tacos',       price: 85,  img: TOS, available: true },
];

window.SR.CATEGORIES = ['Entradas', 'Plato Fuerte', 'Tacos'];

window.SR.TABLES = [
  { id: 't1', name: 'Mesa 01', seats: 2 },
  { id: 't2', name: 'Mesa 02', seats: 4 },
  { id: 't3', name: 'Mesa 03', seats: 4 },
  { id: 't4', name: 'Mesa 04', seats: 6 },
  { id: 't5', name: 'Terraza 01', seats: 2 },
  { id: 't6', name: 'Barra', seats: 8 },
];

window.SR.EMPLOYEES = [
  { id: 'e1', name: 'Julio R.',  role: 'Dueño',   initials: 'JR', grad: 'linear-gradient(135deg,#C4633F,#C9A24A)', home: 'dashboard' },
  { id: 'e2', name: 'Sofía M.',  role: 'Mesero',  initials: 'SM', grad: 'linear-gradient(135deg,#1A1E2E,#C4633F)', home: 'pos' },
  { id: 'e3', name: 'Diego L.',  role: 'Cocina',  initials: 'DL', grad: 'linear-gradient(135deg,#232839,#C9A24A)', home: 'pos' },
];

window.SR.NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
  { id: 'pos',       label: 'POS',       icon: 'zap' },
  { id: 'tables',    label: 'Mesas',     icon: 'table-2' },
  { id: 'kitchen',   label: 'Cocina',    icon: 'chef-hat' },
  { id: 'cashier',   label: 'Caja',      icon: 'receipt' },
  { divider: true },
  { id: 'inventory', label: 'Inventario', icon: 'boxes' },
  { id: 'menu',      label: 'Menú',       icon: 'menu-square' },
  { id: 'settings',  label: 'Ajustes',    icon: 'settings-2' },
];

// Order Line — live orders being prepared (kitchen queue)
window.SR.ORDERS = [
  { id: '#231128001', name: 'Rachmad Jailani', table: 'Mesa 12', pct: 85, items: 6 },
  { id: '#231128002', name: 'Steve Houdini',   table: 'Mesa 09', pct: 60, items: 9 },
  { id: '#231128003', name: 'Maulana Ragnar',  table: 'Mesa 14', pct: 40, items: 12 },
  { id: '#231128004', name: 'Ana Belmont',     table: 'Terraza 01', pct: 20, items: 4 },
];

// Menu tab labels (decorative breadth; filter falls back to full menu)
window.SR.TABS = ['Plato Fuerte', 'Entradas', 'Tacos', 'Favoritos', 'Bebidas', 'Postres', 'Ensaladas', 'Sopas'];

// seed for the "Orden Actual" rail
window.SR.SEED_ORDER = [
  { id: 'm1', name: 'Aguachile Verde', price: 220, qty: 2 },
  { id: 'm5', name: 'Ceviche Mixto', price: 215, qty: 1 },
];

// dashboard mock series
window.SR.REVENUE = [
  { label: 'Lun', v: 28 }, { label: 'Mar', v: 41 }, { label: 'Mié', v: 33 },
  { label: 'Jue', v: 52 }, { label: 'Vie', v: 78 }, { label: 'Sáb', v: 95 }, { label: 'Dom', v: 61 },
];
window.SR.BEST = [
  { name: 'Aguachile Verde', qty: 142, rev: 31240 },
  { name: 'Ceviche Mixto', qty: 118, rev: 25370 },
  { name: 'Tostada de Atún', qty: 96, rev: 9120 },
  { name: 'Aguachile Negro', qty: 74, rev: 18130 },
  { name: 'Ceviche del Día', qty: 61, rev: 14030 },
];
