/* ServiRest POS kit — Dashboard screen */

const Dashboard = () => {
  const { REVENUE, BEST } = window.SR;
  const [range, setRange] = React.useState('Semana');
  React.useEffect(() => { window.lucide && window.lucide.createIcons(); });

  const KPIS = [
    { label: 'Ventas Netas', value: '$48,320', icon: 'trending-up', delta: '▲ +12%', dc: '#22A06B' },
    { label: 'Platillos', value: '642', icon: 'utensils', delta: '7 días', dc: 'rgba(42,40,38,0.4)' },
    { label: 'Cancelaciones', value: '$1,240', icon: 'ban', delta: '3 órdenes', dc: '#E1554B' },
    { label: 'Ticket Med.', value: '$418', icon: 'receipt', delta: '▲ +4%', dc: '#22A06B' },
    { label: 'Gastos Caja', value: '$18,900', icon: 'wallet', delta: 'Prime cost', dc: 'rgba(42,40,38,0.4)' },
    { label: 'Flujo Estim.', value: '$29,420', icon: 'banknote', delta: '▲ saludable', dc: '#22A06B' },
  ];
  const max = Math.max(...REVENUE.map(r => r.v));
  const EXP = [['Carnes y Pescado', 8420], ['Bebidas', 3110], ['Abarrotes', 2940], ['Nómina', 12500], ['Renta', 9000]];

  return (
    <div className="dash no-sb">
      <div className="dash-head">
        <div>
          <h1>ServiRest</h1>
          <div className="sub">Orquestación financiera en tiempo real</div>
        </div>
        <div className="dash-tools">
          <div className="range">
            {['Día', 'Semana', 'Mes', 'Año'].map(r => (
              <button key={r} className={range === r ? 'on' : ''} onClick={() => setRange(r)}>{r}</button>
            ))}
          </div>
          <button className="dash-export"><i data-lucide="file-text" style={{ width: 16, height: 16 }}></i>Exportar reporte</button>
        </div>
      </div>

      <div className="kpis">
        {KPIS.map((k, i) => (
          <div key={i} className="kpi">
            <i data-lucide={k.icon} className="ic" style={{ width: 20, height: 20 }}></i>
            <div className="kl">{k.label}</div>
            <div className="kv">{k.value}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 9, marginTop: 5, color: k.dc }}>{k.delta}</div>
          </div>
        ))}
      </div>

      <div className="dash-row">
        <div className="panel">
          <div className="pk">Proyección financiera</div>
          <div className="pt">Ventas por día</div>
          <div className="bars">
            {REVENUE.map((r, i) => (
              <div key={i} className="bar-col">
                <div className="bar" style={{ height: `${(r.v / max) * 100}%` }}></div>
                <div className="bl">{r.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="panel">
          <div className="pk">Operación</div>
          <div className="pt">Distribución de gastos</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 4 }}>
            {EXP.map(([cat, val], i) => {
              const m = Math.max(...EXP.map(e => e[1]));
              return (
                <div key={i}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontWeight: 800, fontSize: 10, color: 'rgba(42,40,38,0.6)' }}>{cat}</span>
                    <span style={{ fontWeight: 900, fontSize: 10, color: '#C4633F' }}>${val.toLocaleString()}</span>
                  </div>
                  <div style={{ height: 5, background: 'rgba(42,40,38,0.07)', borderRadius: 3 }}>
                    <div style={{ height: '100%', width: `${(val / m) * 100}%`, background: '#C4633F', borderRadius: 3 }}></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="panel">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <i data-lucide="arrow-up-right" style={{ width: 20, height: 20, color: '#22A06B' }}></i>
            <span style={{ fontWeight: 900, fontStyle: 'italic', textTransform: 'uppercase', fontSize: 17, color: '#1A1E2E' }}>Best Sellers · Top 5</span>
          </div>
          <span style={{ fontWeight: 900, fontSize: 9, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(42,40,38,0.4)' }}>642 ventas</span>
        </div>
        {BEST.map((p, i) => (
          <div key={i} className="rank">
            <div className="lt">
              <span className="num">#{i + 1}</span>
              <span className="rn">{p.name}</span>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div className="rv">{p.qty} unid.</div>
              <div className="rr">${p.rev.toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

window.Dashboard = Dashboard;
