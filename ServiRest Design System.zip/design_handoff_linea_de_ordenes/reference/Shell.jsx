/* ServiRest POS kit — shell: Logo, Splash, Lock, Sidebar */

const Plato = ({ variant = 'light', size = 48 }) => {
  const c = variant === 'midnight'
    ? { circle: '#FAF8F4', path: '#C9A24A' }
    : variant === 'mono' ? { circle: 'currentColor', path: 'currentColor' }
    : { circle: '#1A1E2E', path: '#C4633F' };
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="38" fill="none" stroke={c.circle} strokeWidth="6" vectorEffect="non-scaling-stroke" />
      <path d="M 35,62 C 30,52 42,44 50,48 C 60,52 58,68 46,66 C 30,64 28,42 50,38 C 72,34 74,68 50,72"
        fill="none" stroke={c.path} strokeWidth="4.5" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

const Splash = () => (
  <div className="splash">
    <Plato variant="midnight" size={76} />
    <div className="word">ServiRest</div>
    <div className="dots"><i></i><i></i><i></i></div>
  </div>
);

const Lock = ({ onPick }) => (
  <div className="lock">
    <div className="lock-brand">
      <Plato variant="midnight" size={34} />
      <span className="word">ServiRest</span>
    </div>
    <p className="lock-sub">Selecciona tu perfil para abrir el turno</p>
    <div className="profiles">
      {window.SR.EMPLOYEES.map((e, i) => (
        <button key={e.id} className="profile" onClick={() => onPick(e)}>
          <span className="avatar" style={{ background: e.grad }}>{e.initials}</span>
          <span className="pname">{e.name}</span>
          <span className="prole">{e.role}</span>
        </button>
      ))}
    </div>
  </div>
);

const Sidebar = ({ active, onNav, employee, onLock }) => {
  const [open, setOpen] = React.useState(false);
  return (
    <aside className="sidebar" style={{ width: open ? 256 : 96 }}
      onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <div className="sb-head" style={{ justifyContent: open ? 'flex-start' : 'center' }}>
        <div className="sb-mark"><Plato variant="midnight" size={30} /></div>
        {open && (
          <div className="sb-title">
            <div className="word">ServiRest</div>
            <div className="tag">POS Restaurante</div>
          </div>
        )}
      </div>

      <nav className="sb-nav no-sb">
        {window.SR.NAV.map((item, i) => item.divider ? (
          <div key={i} className="sb-divider" style={{ width: open ? '100%' : 32 }} />
        ) : (
          <button key={item.id}
            className={`nav-item ${active === item.id ? 'active' : ''}`}
            style={{ justifyContent: open ? 'flex-start' : 'center', gap: open ? 16 : 0, padding: open ? '0 18px' : 0 }}
            onClick={() => onNav(item.id)}>
            <i data-lucide={item.icon} style={{ width: 20, height: 20 }}></i>
            {open && <span className="nl">{item.label}</span>}
          </button>
        ))}
      </nav>

      {open && (
        <div className="sb-status">
          <div className="d1">24D</div>
          <div className="d2">● ServiRest Activo</div>
        </div>
      )}

      <div className="sb-foot">
        <button className="sb-user" style={{ width: '100%', border: 'none' }} onClick={onLock} title="Bloquear terminal">
          <span className="avatar" style={{ background: employee.grad }}>{employee.initials}</span>
          {open && (
            <div style={{ flex: 1, textAlign: 'left' }}>
              <div className="un">{employee.name}</div>
              <div className="ur">{employee.role}</div>
            </div>
          )}
          {open && <i data-lucide="lock" style={{ width: 14, height: 14, color: 'rgba(250,248,244,0.25)' }}></i>}
        </button>
      </div>
    </aside>
  );
};

Object.assign(window, { Plato, Splash, Lock, Sidebar });
