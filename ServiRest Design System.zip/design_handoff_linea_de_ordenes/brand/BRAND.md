# ServiRest — Design System

> **Sobremesa Lúcida** · The brand & UI system for ServiRest, an all-in-one restaurant
> management platform (POS + admin + AI) for independent restaurant owners in **Mexico
> and the US-Hispanic market**.

ServiRest's pitch: *"Administración, atención y operación de tu restaurante en un solo
lugar."* It positions itself as the **ally of the trade** ("aliados del rubro, no
proveedores carísimos") against incumbents like Toast and Soft Restaurante — modern,
honest, AI-native, and radically affordable (no setup fees, no sales reps, self-serve).

The product is built around three pillars that organize *all* communication and features:

| Pilar | What it covers | Dominant persona |
|---|---|---|
| **Administración** | Finanzas, inventario, food cost, dashboard ejecutivo, reportes, alertas | Dueño-CEO ("CEO Operativo") |
| **Atención** | App de meseros, AI assistant de reservas, mesas, propinas, status de pedidos | Dueño-Chef ("Pilas") |
| **Operación** | Workflow mesero→cocina→caja, inventario, importador SoftRest/Excel, POS | Ambas |

**Two customer personas**, both LATAM-MX + US-Hispanic:
- **Persona 1 — Dueño-Chef "Pilas"** (35-50): hands-on, in the kitchen & on the floor,
  1-2 locations, decides fast (1-2 weeks) on a live demo + a peer success story.
- **Persona 2 — Dueño-Monitor "CEO Operativo"** (40-60): supervises remotely, 2-5
  locations, decides slowly (2-6 weeks) on a pilot + ROI math.

---

## Sources (provided inputs — store even if you can't access)

| Source | What it is | Notes |
|---|---|---|
| `uploads/SERVIREST.html` | **Propuesta maestra v3** — the founder-approved brand bible | Palette "Sobremesa Lúcida", "El Plato" logo system, voice/archetype, tagline system, personas, pricing. Primary brand source. |
| GitHub: **[JulioRonin/restaurant-POS](https://github.com/JulioRonin/restaurant-POS)** | The actual product codebase (React + TypeScript + Tailwind + Vite + Supabase) | Already rebranded to ServiRest. `index.css`, `tailwind.config.js`, `components/`, `screens/` are the UI source of truth. Explore it for deeper component fidelity. |
| `uploads/original-…webp` | A reference POS dashboard screenshot (blue, third-party) | Layout inspiration only — **not** ServiRest's palette. Ignored for color. |

**Explore the repo further** to build higher-fidelity designs: the real screens
(`screens/POS.tsx`, `Dashboard.tsx`, `Hostess.tsx`, `Kitchen.tsx`, `Inventory.tsx`,
`Settings.tsx`, etc.) and components (`Sidebar.tsx`, `Logo.tsx`, `ui/spotlight-card.tsx`)
contain exact class lists and behaviors worth lifting.

> ⚠️ **Brand drift note.** The codebase carries two color generations. The **canonical**
> brand is *Sobremesa Lúcida* (`tailwind.config.js` → `servirest.*`, used by `Sidebar`,
> `Logo`, `Dashboard`, `index.css`). A few legacy screens (e.g. `POS.tsx`) still hardcode
> the older **KŌSO** palette (olive `#505530`, salmon `#F98359`, canvas `#F0F0E8`). This
> design system standardizes on **Sobremesa Lúcida**. When you see olive/salmon in old
> code, map it to terracota/midnight/hueso.

---

## CONTENT FUNDAMENTALS — how ServiRest writes

**Language:** Spanish (neutral, with a subtle Mexican flavor), occasionally bilingual for
the US-Hispanic market. UI numbers/dates can appear in English-ish dev shorthand inside
the product, but customer-facing copy is Spanish.

**Voice archetype: "El Hermano del Rubro"** = Hero + Regular Guy + a dash of Sage.
Combative against incumbents, humble and peer-to-peer, backed by honest data.

**Eight voice keywords** that should breathe through every line:
`cálido · accesible · honesto · operativo · luchador · directo · hermano-del-rubro · con-datos`

**Person & address:** Speaks to the owner directly as **"tú"** ("Cierra el domingo en 30
minutos", "Tu mesero ya sabe qué mesa pidió"). First-person plural for the company
("Te servimos para que sirvas mejor"). Peer, never vendor.

**Tone & casing:**
- Customer copy: warm, plainspoken, confident. Short declarative sentences. Data when it
  helps ("reduce food cost 6-12%", "ahorrá 8 horas/semana") — never vague hype.
- **UI micro-labels are UPPERCASE** with heavy letter-spacing (`ESTADO DEL NODO`,
  `VENTAS NETAS`, `TICKET MED.`). Display headers are serif italic. Both coexist.
- Section eyebrows/kickers: tiny uppercase, often *italic*, frequently terracota.

**Vocabulary rules (from the brand bible):**
- ✅ "platillo", "checa", a very occasional "órale" · ✅ "Restaurante" (not "resto") ·
  ✅ "Dueño" (not "owner") · ✅ "Mesero" (MX) / "Mozo" (AR) · ✅ "Cierre del día" (not "cuadre")
- ❌ "wey/güey", "chido", "padrísimo" (too regionally MX — alienates non-MX Hispanic)
- ❌ Latino cliché (sombreros, cactus, calaveritas, mariachis). The *latinidad* lives in
  warmth of the cream, the copper texture, generous spacing — never in kitsch.

**Taglines (don't invent new ones — these five cover 100% of cases):**
- Master (hero): *"ServiRest: administración, atención y operación de tu restaurante en un solo lugar."*
- Anti-incumbent: *"El GoHighLevel de restaurantes."*
- Hero punch: *"Aliados del rubro. No proveedores carísimos."*
- Warm service: *"Te servimos para que sirvas mejor."*
- Expanded: *"…Sin Excel. Sin Soft Restaurante. Sin pagar lo que cobran los gigantes."*

**Two "nunca" commitments (non-negotiable, define what ServiRest is NOT):**
1. Never have sales reps cold-calling. 2. Never charge setup/install/training fees.

**Emoji:** Not used in product UI or brand copy. Status is shown with Lucide icons,
colored dots, and check/✓ glyphs in internal proposal docs only.

---

## VISUAL FOUNDATIONS — Sobremesa Lúcida

**The big idea:** one brand, two shifts of the day. **Midnight** is ServiRest *closing the
night* (sobremesa — warm, tinto, candle-low). **Blanco Hueso** is ServiRest *starting the
morning* (clinical, lucid, KPI-clear). The product canvas is the *day* (cream + carbon +
terracota); the chrome/sidebar/splash is the *night* (midnight gradient).

**Color** — 5 hexes, nothing else:
- `#1A1E2E` Midnight Tinto — primary; sidebar, splash, dark surfaces, headings
- `#C4633F` Terracota — secondary; CTAs, hero, active nav, emotional accents
- `#C9A24A` Mostaza Mate — accent; signals, KPI numbers, badges (the "look here" color)
- `#FAF8F4` Blanco Hueso — surface; the app canvas (reads like paper, never pure white)
- `#2A2826` Gris Carbón — body text on cream (never pure black)
- Rule of thumb: **Terracota = emotion** (CTA/hero/photo). **Mostaza = information**
  (badges, important numbers). Function, not taste. Zero pure black, zero pure white.

**Type** — three families, all on Google Fonts:
- **Fraunces** (variable serif) — display & brand. Almost always *italic*, optical-size
  maxed (`opsz 144`), soft/wonk on. Warm, editorial, "sello de la casa".
- **Inter** — everything functional: body, labels, buttons. Its signature use here is
  **black (900) + italic + UPPERCASE + tight tracking** for headers and KPIs ("brutal" mode).
- **JetBrains Mono** — prices, IDs, timestamps, code, raw numerics.

**Spacing & layout:** generous negative space (Apollo-like rigor). Cards float on the
cream canvas. Fixed dark sidebar (collapses 96px → 256px on hover with the
`cubic-bezier(0.23,1,0.32,1)` "solaris" ease). Mobile gets a bottom nav bar instead.

**Corner radii:** large and soft. Default card `24px`; hero cards / modals / nav pills use
`2rem` (32px, the `solaris` radius); small controls `8–12px`; avatars and source-buttons
fully rounded. The roundness is a core brand signal — nothing is sharp-cornered.

**Cards:** white surface, hairline border (`rgba(42,40,38,0.12)`), soft ambient shadow
`0 2px 20px rgba(42,40,38,.08)`. On photo/hero contexts, switch to **glass**
(`rgba(250,248,244,.88)` + `blur(12px)`). No colored-left-border cards. No heavy borders.

**Shadows & glow (the "Solaris glow engine"):** the signature elevation is a **terracota
glow** — `0 0 20px rgba(196,99,63,.40)` on primary buttons & active nav, a softer
`0 0 40px rgba(196,99,63,.12)` for ambient. Dark elements use a midnight glow. KPI/spotlight
cards carry an optional cursor-following radial highlight (`[data-glow]`).

**Hover / press states:**
- Hover: lift + subtle scale up (`translateY(-2px)` / `scale(1.02)`), border warms to
  terracota, glow intensifies. Nav items go from 50%-opacity hueso to full + terracota bg.
- Press: `scale(0.95–0.97)` (tactile shrink). Active nav also scales *up* (105%) to feel selected.

**Animation:** framer-motion. Soft fade-up entrances (`opacity 0→1, translateY 10→0`,
~0.4s ease-out, `.animate-soft-fade-in`). Layout animations on grids. Splash holds ~2.5s.
Pulsing dots for "online/live" status. Easing is the `solaris` cubic-bezier for panels,
ease-out for micro-interactions. No bounces, no infinite decorative loops on content.

**Imagery:** real, warm, top-lit food photography (Mexican cuisine — aguachile, ceviche,
tostada). Shot on wood/stone with warm naturalistic light; no B&W, no heavy grain. Product
screenshots and "uso real" behind-the-scenes are the hero content type.

**Transparency & blur:** used for glass cards over imagery, modal scrims
(`bg-black/90 backdrop-blur-xl`), and the sidebar's subtle inner panels. Purposeful, not
decorative.

---

## ICONOGRAPHY

- **Icon set: [Lucide](https://lucide.dev)** (`lucide-react` in the codebase). Clean,
  consistent **2px stroke**, rounded line caps/joins — matches the soft-corner brand.
  Sizes 12–24px in UI; stroke stays 2. Pull from the Lucide CDN (`unpkg lucide@latest`)
  for HTML mocks. Common glyphs in use: `LayoutDashboard, Zap (POS), Table2, MonitorCheck
  (hostess), Receipt (caja), ChefHat (cocina), Wine (bar), Smartphone, MenuSquare, Users,
  Boxes (inventario), CreditCard, Settings2, Lock, LogOut, Search, Plus, Minus, Trash2,
  ShoppingCart, CheckCircle2, TrendingUp, Wallet, FileText`.
- **Logo / brand mark: "El Plato Asimétrico"** — a circle (the plate) with an organic
  off-center spiral (pasta on a fork / a hand-drawn gesture / an abstract "S"). Two color
  variants (see `assets/`):
  - *Light* (on cream): midnight circle + terracota spiral.
  - *Midnight* (on dark): hueso circle + mostaza spiral.
  - Stroke `6` (circle) / `4.5` (spiral), `non-scaling-stroke`, round caps. Favicon uses
    thicker strokes (9 / 6.5). It reads as a wax seal — ornamental but functional.
- **Emoji:** none. **Unicode as icon:** sparingly (✓ checks, `→` arrows, `·` separators).
- Never hand-draw new iconography or substitute emoji — use Lucide, or the El Plato mark.

---

## Index — what's in this system

| Path | What |
|---|---|
| `README.md` | This file — context, content & visual foundations, iconography, manifest |
| `colors_and_type.css` | All color + type tokens (CSS vars) and primitive classes (`.sr-*`) |
| `SKILL.md` | Agent-Skill front-matter so this folder works as a Claude Skill |
| `assets/` | Logo variants (`logo-plato-light/midnight.svg`), `favicon.svg`, food photos (`food/`) |
| `preview/` | Design-system cards (colors, type, components, brand) shown in the DS tab |
| `ui_kits/pos/` | High-fidelity recreation of the ServiRest POS — `index.html` + JSX components |

**Fonts:** Fraunces, Inter, JetBrains Mono — all loaded from Google Fonts (see the
`@import` at the top of `colors_and_type.css`). No local font files needed.
